package com.mycodeopslab.cataladojogos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CataladojogosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CataladojogosApplication.class, args);
	}

}
